import java.util.ArrayList;
/**
 * Zura Mestiashvili
 * v1.0.0
 */
public class ArrayListIntegerContainer extends IntegerContainer{
   
    
    public ArrayListIntegerContainer(){
        this.data = new ArrayList<Integer>();
    }
    
}
