import java.util.LinkedList;

/**
 * Zura Mestiashvili
 * v1.0.0
 */
public class LinkedListIntegerContainer extends IntegerContainer{
   
    public LinkedListIntegerContainer(){
        this.data = new LinkedList<Integer>();
    }
    
}
