
/**
 * Zura Mestiashvili
 * v1.0.0
 */
public interface SortedList
{
     void addElement(String s);
     void clearAL();
     int getSize();
     String getElement(int i);
     void setElement(int i, String s);
     String printData();
}
