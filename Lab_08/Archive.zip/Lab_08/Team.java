public class Team{
    String foo;
    String boo;
    
    public Team(){
        this.foo = "foo";
        this.boo = "boo";
    }
    
    public String getFoo(){
        return this.foo;
    }
    
    public String getBoo(){
        return this.boo;
    }
}
