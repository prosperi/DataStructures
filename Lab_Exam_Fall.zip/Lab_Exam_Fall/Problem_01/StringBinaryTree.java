

public class StringBinaryTree{
    
    public static void main(String args[]){
        BinaryTree<String> bt = new BinaryTree<String>();
        bt.add("8");
        bt.add("4");
        bt.add("10");
        bt.add("2");
        bt.add("6");
        bt.add("9");
        bt.add("12");
        bt.add("1");
        bt.add("3");
        bt.add("5");
        bt.add("7");
        bt.add("11");
        bt.add("13");
        
        System.out.println(bt);
    }
    
}
